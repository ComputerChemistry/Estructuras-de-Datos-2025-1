#ifndef VECTOR_HPP_INCLUDED
#define VECTOR_HPP_INCLUDED

#include <iostream>

#define MAX_DIM 10

class Vector{
    friend Vector operator*(double escalar, const Vector v);
    friend std::ostream & operator<<(std::ostream &salida, const Vector v);
    friend std::istream & operator>>(std::istream &entrada, Vector &v);
public:
    Vector();
    explicit Vector(int dimension);
    Vector(int dimension, double valor);

    int ObtenerDim() const;

    void Imprimir() const;
    void Capturar();

    Vector operator+(const Vector v) const;
    Vector operator-(const Vector v) const;
    double operator*(const Vector v) const;
    Vector operator*(const double escalar) const;
    double Magnitud() const;

    double operator[](int i) const;
    double & operator[](int i);

private:
    int dim;
    double componente[MAX_DIM];
    // M�todos de utiler�a
    void EstablecerDim(int dimension);

};



#endif // VECTOR_HPP_INCLUDED
