var Matriz_8hpp =
[
    [ "Matriz", "classMatriz.html", "classMatriz" ],
    [ "operator*", "Matriz_8hpp.html#abf5ab917b99d243a3627dbe53dd58ba3", null ]
];