var annotated_dup =
[
    [ "Complejo", "classComplejo.html", "classComplejo" ],
    [ "Matriz", "classMatriz.html", "classMatriz" ],
    [ "Pila", "classPila.html", "classPila" ],
    [ "Polinomio", "classPolinomio.html", "classPolinomio" ],
    [ "Vector", "classVector.html", "classVector" ]
];