var classComplejo =
[
    [ "Complejo", "classComplejo.html#ae30824ae1d0110edf614ace7be618af3", null ],
    [ "Imprimir", "classComplejo.html#aba6dc87dbdf48db494de4b00f1b34186", null ],
    [ "ObtenerImaginario", "classComplejo.html#a7207c3eb4012d8e61bf0a060f9eb603c", null ],
    [ "ObtenerReal", "classComplejo.html#a0ed8279407a2c9e33a72d33919ffa6f0", null ],
    [ "operator+", "classComplejo.html#ac085f9863f8e7def313e10b678960940", null ],
    [ "operator<<", "classComplejo.html#a3bbd00597621c957b6c3ecfc105c228e", null ]
];