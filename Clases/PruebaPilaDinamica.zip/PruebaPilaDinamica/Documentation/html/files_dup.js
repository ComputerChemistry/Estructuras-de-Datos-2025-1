var files_dup =
[
    [ "Complejo.hpp", "Complejo_8hpp.html", "Complejo_8hpp" ],
    [ "Matriz.hpp", "Matriz_8hpp.html", "Matriz_8hpp" ],
    [ "Pila.hpp", "Pila_8hpp.html", "Pila_8hpp" ],
    [ "Polinomio.hpp", "Polinomio_8hpp.html", "Polinomio_8hpp" ],
    [ "Vector.hpp", "Vector_8hpp.html", "Vector_8hpp" ]
];