var searchData=
[
  ['imprimir_0',['Imprimir',['../classComplejo.html#aba6dc87dbdf48db494de4b00f1b34186',1,'Complejo::Imprimir()'],['../classPila.html#adb11ed728217393f2c27ffcb16fce76a',1,'Pila::Imprimir()'],['../classPolinomio.html#af5d5438410d0d9ab6de14a0a64500839',1,'Polinomio::Imprimir()'],['../classVector.html#aa601691aa698be4b72cab179bc563fdd',1,'Vector::Imprimir()']]],
  ['inversa_1',['inversa',['../classMatriz.html#a27cc0bfaf413e791f7e91d6ddfcffab1',1,'Matriz']]]
];
