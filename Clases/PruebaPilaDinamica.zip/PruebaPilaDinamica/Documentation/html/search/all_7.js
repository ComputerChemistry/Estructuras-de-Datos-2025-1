var searchData=
[
  ['pila_0',['Pila',['../classPila.html',1,'Pila&lt; Tipo &gt;'],['../classPila.html#a484eff9e77c68d181220f0cc237bdaad',1,'Pila::Pila()'],['../classPila.html#a90ba043fa93a6d8f79f41621d27084b2',1,'Pila::Pila(const Pila&lt; Tipo &gt; &amp;otra)']]],
  ['pila_2ehpp_1',['Pila.hpp',['../Pila_8hpp.html',1,'']]],
  ['polinomio_2',['Polinomio',['../classPolinomio.html',1,'Polinomio'],['../classPolinomio.html#ac910fd7c555f384a2b12a8f498acd2f4',1,'Polinomio::Polinomio()'],['../classPolinomio.html#a6d25459cb05f1a4b7ba1c4d11b31e467',1,'Polinomio::Polinomio(std::initializer_list&lt; double &gt; coef)'],['../classPolinomio.html#a1f1002c4ef435333ccee6cb82e70e83b',1,'Polinomio::Polinomio(const std::vector&lt; double &gt; &amp;coef)']]],
  ['polinomio_2ehpp_3',['Polinomio.hpp',['../Polinomio_8hpp.html',1,'']]]
];
