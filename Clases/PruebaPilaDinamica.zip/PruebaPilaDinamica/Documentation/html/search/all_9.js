var searchData=
[
  ['transpuesta_0',['transpuesta',['../classMatriz.html#a501ab4dd96e9efee6a6ecd7e2919f128',1,'Matriz']]]
];
