var searchData=
[
  ['obtenercapacidad_0',['ObtenerCapacidad',['../classPila.html#ab7f3c2ec2555db3e79363a964134b1c5',1,'Pila']]],
  ['obtenertamanio_1',['ObtenerTamanio',['../classPila.html#abee90977da44f0d9fdb3531fa0461471',1,'Pila']]],
  ['obtenertope_2',['ObtenerTope',['../classPila.html#a8e9339b23320b0286ce668a7b7ccf5c8',1,'Pila']]],
  ['operator_3d_3',['operator=',['../classPila.html#a6ccf73b83f1b0fc3d9bff4799db8381f',1,'Pila']]]
];
