var classMatriz =
[
    [ "Matriz", "classMatriz.html#abc9912569340cd1d64d25327b5398d42", null ],
    [ "~Matriz", "classMatriz.html#a2092b7a289ecec369e1da407d5839f5a", null ],
    [ "Matriz", "classMatriz.html#a7a9316f6f7dce40a20ba19b0f83261bb", null ],
    [ "inversa", "classMatriz.html#a27cc0bfaf413e791f7e91d6ddfcffab1", null ],
    [ "operator*", "classMatriz.html#a6847e6e306b4aaa5d693d82dd86b0836", null ],
    [ "operator*", "classMatriz.html#ab50a7af460b0627efd67124ebc2b6b64", null ],
    [ "operator+", "classMatriz.html#a10a5d942cf40951122571a5175b21b7c", null ],
    [ "operator-", "classMatriz.html#ae093ee666a38d111f7babb7fd3a254ee", null ],
    [ "operator=", "classMatriz.html#a6022b19c81ebf4acced02ad8887c94e9", null ],
    [ "redimensionar", "classMatriz.html#a53fd99a9078d45001613102a4a8bc9d7", null ],
    [ "transpuesta", "classMatriz.html#a501ab4dd96e9efee6a6ecd7e2919f128", null ],
    [ "operator<<", "classMatriz.html#ad5bd275aa4b7a32f19ec368d2f98223d", null ],
    [ "operator>>", "classMatriz.html#afd824d0c6b588c874d06cb6197f4e3af", null ]
];