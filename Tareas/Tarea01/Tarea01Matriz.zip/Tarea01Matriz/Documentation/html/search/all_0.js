var searchData=
[
  ['inversa_0',['inversa',['../classMatriz.html#a27cc0bfaf413e791f7e91d6ddfcffab1',1,'Matriz']]]
];
