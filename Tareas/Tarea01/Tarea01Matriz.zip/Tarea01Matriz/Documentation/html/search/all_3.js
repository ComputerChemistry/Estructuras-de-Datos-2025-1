var searchData=
[
  ['redimensionar_0',['redimensionar',['../classMatriz.html#a53fd99a9078d45001613102a4a8bc9d7',1,'Matriz']]]
];
