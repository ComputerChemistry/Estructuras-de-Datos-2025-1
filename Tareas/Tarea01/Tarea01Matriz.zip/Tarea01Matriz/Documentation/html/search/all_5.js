var searchData=
[
  ['_7ematriz_0',['~Matriz',['../classMatriz.html#a2092b7a289ecec369e1da407d5839f5a',1,'Matriz']]]
];
