var searchData=
[
  ['matriz_0',['Matriz',['../classMatriz.html#abc9912569340cd1d64d25327b5398d42',1,'Matriz::Matriz(unsigned int f=1, unsigned int c=1)'],['../classMatriz.html#a7a9316f6f7dce40a20ba19b0f83261bb',1,'Matriz::Matriz(const Matriz &amp;otra)']]]
];
