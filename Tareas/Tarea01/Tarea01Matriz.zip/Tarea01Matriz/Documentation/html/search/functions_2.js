var searchData=
[
  ['operator_2a_0',['operator*',['../classMatriz.html#a6847e6e306b4aaa5d693d82dd86b0836',1,'Matriz::operator*(const Matriz &amp;otra) const'],['../classMatriz.html#ab50a7af460b0627efd67124ebc2b6b64',1,'Matriz::operator*(double escalar) const'],['../Matriz_8hpp.html#abf5ab917b99d243a3627dbe53dd58ba3',1,'operator*():&#160;Matriz.hpp']]],
  ['operator_2b_1',['operator+',['../classMatriz.html#a10a5d942cf40951122571a5175b21b7c',1,'Matriz']]],
  ['operator_2d_2',['operator-',['../classMatriz.html#ae093ee666a38d111f7babb7fd3a254ee',1,'Matriz']]],
  ['operator_3d_3',['operator=',['../classMatriz.html#a6022b19c81ebf4acced02ad8887c94e9',1,'Matriz']]]
];
