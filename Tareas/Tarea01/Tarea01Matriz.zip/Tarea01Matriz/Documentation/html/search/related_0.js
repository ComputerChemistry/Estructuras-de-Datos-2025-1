var searchData=
[
  ['operator_3c_3c_0',['operator&lt;&lt;',['../classMatriz.html#ad5bd275aa4b7a32f19ec368d2f98223d',1,'Matriz']]],
  ['operator_3e_3e_1',['operator&gt;&gt;',['../classMatriz.html#afd824d0c6b588c874d06cb6197f4e3af',1,'Matriz']]]
];
