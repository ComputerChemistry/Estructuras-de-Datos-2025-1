var indexSectionsWithContent =
{
  0: "imort~",
  1: "m",
  2: "m",
  3: "imort~",
  4: "o"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "related"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Files",
  3: "Functions",
  4: "Friends"
};

