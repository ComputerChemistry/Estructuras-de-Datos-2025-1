var searchData=
[
  ['pila_0',['Pila',['../classPila.html#a484eff9e77c68d181220f0cc237bdaad',1,'Pila::Pila()'],['../classPila.html#a90ba043fa93a6d8f79f41621d27084b2',1,'Pila::Pila(const Pila&lt; Tipo &gt; &amp;otra)']]]
];
