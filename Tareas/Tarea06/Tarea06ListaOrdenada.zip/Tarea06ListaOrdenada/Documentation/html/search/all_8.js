var searchData=
[
  ['remove_0',['remove',['../classOrderedList.html#a10a7767b1589357fc7a7caa3a611d743',1,'OrderedList']]]
];
