var indexSectionsWithContent =
{
  0: "acfgimopr~",
  1: "o",
  2: "o",
  3: "acfgimopr~"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions"
};

var indexSectionLabels =
{
  0: "Todos",
  1: "Clases",
  2: "Archivos",
  3: "Funciones"
};

